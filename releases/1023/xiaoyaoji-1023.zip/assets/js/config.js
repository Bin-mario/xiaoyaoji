toastr.options.escapeHtml = true;
toastr.options.closeButton = true;
toastr.options.positionClass = 'toast-top-center';
toastr.options.preventDuplicates=true;
window._xyj_={
    history:false,
    version:'1.6',
    api:'',
    //api:'//localhost:9999',
    ws:''
};
console.log('version:'+_xyj_.version);