define(function(require,exports,module){
    module.exports={
        username:'邮箱',
        nickname:'昵称',
        password:'密码'
    }
});
