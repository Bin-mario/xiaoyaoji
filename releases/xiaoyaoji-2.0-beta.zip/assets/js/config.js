toastr.options.escapeHtml = true;
toastr.options.closeButton = true;
toastr.options.positionClass = 'toast-top-center';
toastr.options.preventDuplicates=true;
window._xyj_={
    history:false,
    version:'1.7',
    //api:'//www.xiaoyaoji.com.cn',
    api:'',
    //ws:'ws://www.xiaoyaoji.com.cn'
};