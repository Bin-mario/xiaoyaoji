define([],function(){
    return {}
})